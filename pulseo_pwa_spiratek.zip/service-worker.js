self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => self.clients.claim());
self.addEventListener('fetch', e => {
  const url = new URL(e.request.url);
  const staticExt = ['.css','.js','.png','.webmanifest','.svg'];
  if(staticExt.some(ext => url.pathname.endsWith(ext))){
    e.respondWith(caches.open('pulseo-static-v1').then(async cache => {
      const cached = await cache.match(e.request);
      if(cached) return cached;
      const resp = await fetch(e.request);
      cache.put(e.request, resp.clone());
      return resp;
    }));
  }
});
