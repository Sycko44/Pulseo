# Pulseo — PWA minimaliste (revue Spiratek)

Date de build: 2025-08-29T10:16:59.575657Z

## Ce que c’est
- Démo **installable** (PWA) : Splash → Consentement → Chat.
- **Web vs App** clairement indiqué (options grisées + section “Fonctions indisponibles sur Web”).
- **Confidentialité** : local-first, opt-in, pas d’audio auto, pas d’envoi réseau.
- **Accessibilité** : labels ARIA, focus visible, lien “Aller au contenu”.
- **Performance** : assets légers, SW qui ne met en cache que les fichiers statiques.

## Spiratek — Checklist validée
- ✅ Onboarding 2 écrans, questions minimales.
- ✅ Options affichées avec statuts “Complet / Partiel / App uniquement”.
- ✅ CNIL : pas d’écoute de fond, consentement explicite.
- ✅ Noindex + headers sécurité (via `vercel.json`).
- ✅ SW n’intercepte pas les pages privées.
- ✅ A11y de base (contraste, focus, SR-only labels).

## Déploiement (Vercel)
1. Crée un projet sur https://vercel.com
2. Déploie ce dossier (Drag & Drop ou Git).
3. Tu as l’URL `https://<projet>.vercel.app` (privée de facto par l’URL + noindex).
4. Pour un vrai mot de passe : **Cloudflare Access** (recommandé) ou **Next.js + Middleware**.

## Notes
- Le “passcode” intégré est **une barrière de démo** (côté client). Ne pas considérer comme sécurité.
- Pour l’INPI : fais des captures (splash, consentement, chat, réglages, section App-only, confidentialité).
