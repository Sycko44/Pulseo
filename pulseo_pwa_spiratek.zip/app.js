// Register minimal service worker (assets only)
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(()=>{});
  });
}

// Lightweight passcode gate (demo only). Use Cloudflare Access / Vercel Middleware for real protection.
const gate = document.getElementById('gate');
const appMain = document.getElementById('main');
const pass = document.getElementById('pass');
document.getElementById('enter')?.addEventListener('click', () => {
  if ((pass.value || '').trim().length > 0) {
    gate.classList.add('hidden');
    appMain.classList.remove('hidden');
    appMain.focus();
  } else {
    alert('Code requis (démo)');
    pass.focus();
  }
});

// Consent → Chat
const continueBtn = document.getElementById('continue');
const consentPanel = document.querySelector('.consent');
const chatPanel = document.querySelector('.chat');
continueBtn?.addEventListener('click', () => {
  consentPanel.classList.add('hidden');
  chatPanel.classList.remove('hidden');
  document.getElementById('input')?.focus();
});

// Simple chat mock
const sendBtn = document.getElementById('send');
const input = document.getElementById('input');
const messages = document.getElementById('messages');
sendBtn?.addEventListener('click', send);
input?.addEventListener('keydown', (e)=>{ if(e.key==='Enter'){ e.preventDefault(); send(); }});
function send(){
  const text = (input.value || '').trim();
  if(!text) return;
  addMsg('user', text);
  input.value = '';
  setTimeout(()=> addMsg('bot', 'Reçu. (Démo) Sur Web, certaines fonctions sont limitées. Ouvre ⚙️ pour voir “Web vs App”.'), 350);
}
function addMsg(role, text){
  const div = document.createElement('div');
  div.className = 'msg ' + (role === 'bot' ? 'bot' : 'user');
  div.textContent = text;
  messages.appendChild(div);
  messages.scrollTop = messages.scrollHeight;
}

// Settings dialog
document.getElementById('openSettings')?.addEventListener('click', () => {
  document.getElementById('settings').classList.remove('hidden');
  document.getElementById('settings').focus();
});
document.getElementById('closeSettings')?.addEventListener('click', () => {
  document.getElementById('settings').classList.add('hidden');
});

// Privacy modal
document.getElementById('openPrivacy')?.addEventListener('click', (e) => {
  e.preventDefault();
  document.getElementById('privacy').showModal();
});
document.getElementById('closePrivacy')?.addEventListener('click', () => {
  document.getElementById('privacy').close();
});

// CTA app
document.getElementById('getApp')?.addEventListener('click', (e) => {
  e.preventDefault();
  alert('Lien Play Store à venir. (Démo)');
});
