# Pulseo Android CI Skeleton

Includes:
- .github/workflows/android-apk.yml
- scripts/decode-keystore.sh
- apps/mobile/package.json

Push to your repo (branch pulseo-monolith), then run the workflow.
