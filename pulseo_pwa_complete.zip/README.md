# Pulseo — PWA complète

Build: 2025-08-29T10:41:52.294538Z

## Ce que ça ajoute par rapport à la version minimaliste
- **Offline-first** : precache + runtime cache, fallback sur `index.html` hors-ligne.
- **Historien léger** : **IndexedDB** pour stocker les échanges + export **récap 7 jours** (.md).
- **Notifications Web (scaffold)** : demande de permission + gestion `push` dans le SW (nécessite VAPID côté serveur).
- **Background Sync (scaffold)** : tag `sync-messages` prêt à utiliser si besoin.
- **i18n** FR/EN auto (détection langue navigateur).
- **Sécurité** : `vercel.json` avec headers (CSP stricte), `robots.txt` (noindex).

## Déployer (Vercel)
1. Importer ce dossier en projet sur https://vercel.com
2. Framework: **Other** · Build command: **(vide)** · Output: **(racine)**
3. Déployer → URL `https://<projet>.vercel.app`

## Notifications Web (VAPID)
- Nécessite un **serveur** pour créer les abonnements et pousser les messages.  
- Cette démo gère uniquement la **permission** et l’event `push` côté SW.

## Historien (IndexedDB)
- Stocke localement les messages saisis/produits.
- Bouton “Exporter mon récap hebdo” → un fichier `.md` est téléchargé.

## CNIL
- Local-first, opt-in, pas d’audio auto, pas d’envoi réseau par défaut.
- Les permissions (push) sont **optionnelles** et explicites.

Bonne démo !
