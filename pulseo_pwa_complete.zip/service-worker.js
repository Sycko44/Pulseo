// SW complet (precache + runtime), push & sync scaffolding
const PRECACHE = 'pulseo-precache-v1';
const RUNTIME = 'pulseo-runtime-v1';
const PRECACHE_URLS = [
  './',
  'index.html',
  'styles.css',
  'app.js',
  'i18n.js',
  'db.js',
  'manifest.webmanifest',
  'icon-192.png',
  'icon-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(PRECACHE).then(cache => cache.addAll(PRECACHE_URLS)).then(self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(k => ![PRECACHE,RUNTIME].includes(k)).map(k => caches.delete(k)))) .then(() => self.clients.claim())
  );
});

// Runtime cache (network-first for html, cache-first for assets)
self.addEventListener('fetch', event => {
  const req = event.request;
  const url = new URL(req.url);
  if (req.method !== 'GET') return;
  if (url.pathname.endsWith('.css') || url.pathname.endsWith('.js') || url.pathname.endsWith('.png') || url.pathname.endsWith('.webmanifest')) {
    event.respondWith(caches.open(RUNTIME).then(async cache => {
      const cached = await cache.match(req);
      if (cached) return cached;
      const resp = await fetch(req);
      cache.put(req, resp.clone());
      return resp;
    }));
    return;
  }
  // HTML: network first, fallback to cache
  event.respondWith(
    fetch(req).catch(() => caches.match('index.html'))
  );
});

// Push (demo)
self.addEventListener('push', event => {
  const data = (event.data && event.data.text()) || 'Pulseo — notification';
  event.waitUntil(self.registration.showNotification('Pulseo', { body: data, icon: 'icon-192.png' }));
});

// Background sync (demo)
self.addEventListener('sync', event => {
  if (event.tag === 'sync-messages') {
    event.waitUntil(Promise.resolve()); // placeholder
  }
});
