# Correctif — Piratech + Spiratek
Ajoute l’auto-correcteur pour Vercel.
- Framework : Other
- Build Command : node check.js
- Output Directory : (vide)

Place ces fichiers à la racine du projet (à côté d’index.html).