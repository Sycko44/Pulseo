# Pulseo — PWA complète (Original)
Build: 2025-08-29T11:38:56.745725Z

Déployer sur Vercel (statique) :
- Framework Preset : Other
- Build Command : (vide)
- Output Directory : (vide)

Fonctions : offline, IndexedDB (Historien), export 7j, i18n FR/EN, push/sync scaffolds, noindex + headers sécurité.
