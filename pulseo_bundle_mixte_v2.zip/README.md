# Pulseo — Bundle mixte (corrigé)

• `pulseo_original/` : PWA complète prête à déployer (statique pur, sans auto-correcteur).
• `pulseo_correctif/` : add-on Piratech (check.js + package.json) à copier à la racine si tu veux l’auto-correction.

Vercel:
- Original → Framework Other, Build: (vide), Output: (vide)
- Avec correctif → Framework Other, Build: node check.js, Output: (vide)
